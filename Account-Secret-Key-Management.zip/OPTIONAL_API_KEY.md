# API Key 可选功能说明

## 功能概述

现在上传账号时，**API Key 字段变为可选**。如果上传的账号文件中没有 API Key，系统会在客户端请求获取账号时，自动通过登录获取 API Key。

## 工作流程

### 1. 上传账号（API Key 可选）

**支持的账号文件格式：**

#### 格式 A：包含 API Key（传统格式）
```
Account 1:
  Email: user1@example.com
  Name: John Doe
  Password: password123
  API Key: sk-ws-01-xxxxx

Account 2:
  Email: user2@example.com
  Name: Jane Smith
  Password: password456
  API Key: sk-ws-01-yyyyy
```

#### 格式 B：不包含 API Key（新格式）
```
Account 1:
  Email: user1@example.com
  Name: John Doe
  Password: password123

Account 2:
  Email: user2@example.com
  Name: Jane Smith
  Password: password456
```

#### 格式 C：混合格式（部分有 API Key）
```
Account 1:
  Email: user1@example.com
  Name: John Doe
  Password: password123
  API Key: sk-ws-01-xxxxx

Account 2:
  Email: user2@example.com
  Name: Jane Smith
  Password: password456
```

### 2. 自动获取 API Key

当客户端请求获取账号时：

1. **检查账号是否有 API Key**
   - 如果有：直接返回账号信息
   - 如果没有：自动执行登录流程

2. **自动登录流程**
   - 使用账号的邮箱和密码
   - 通过 Firebase 认证
   - 调用 Windsurf API 获取 API Key
   - 更新数据库中的账号信息
   - 返回完整的账号信息给客户端

3. **错误处理**
   - 如果登录失败，返回错误信息
   - 账号保持未使用状态，可以稍后重试

## 数据库迁移

### 自动迁移

运行迁移脚本更新数据库结构：

```bash
python migrate_api_key_optional.py
```

### 手动迁移

#### PostgreSQL
```sql
ALTER TABLE accounts ALTER COLUMN api_key DROP NOT NULL;
ALTER TABLE accounts ALTER COLUMN name DROP NOT NULL;
```

#### SQLite
SQLite 需要重建表（参考 migrate_api_key_optional.py 脚本）

## 使用示例

### 示例 1：上传不含 API Key 的账号

**账号文件 (accounts.txt):**
```
Account 1:
  Email: test1@example.com
  Name: Test User 1
  Password: testpass1

Account 2:
  Email: test2@example.com
  Name: Test User 2
  Password: testpass2
```

**上传结果：**
- ✅ 账号成功导入数据库
- ⚠️ API Key 字段为空
- 📝 状态：unused（未使用）

### 示例 2：客户端获取账号

**客户端请求：**
```bash
curl -X POST "http://localhost:8000/api/client/account/get" \
  -H "X-API-Key: your_key_code"
```

**系统处理流程：**
1. 分配一个未使用的账号（test1@example.com）
2. 检测到该账号没有 API Key
3. 自动登录：
   - 使用 test1@example.com 和 testpass1
   - 通过 Firebase 认证
   - 获取 Windsurf API Key
4. 更新数据库：
   - 保存获取到的 API Key
   - 更新账号状态为已使用
5. 返回完整账号信息

**响应示例：**
```json
{
  "email": "test1@example.com",
  "api_key": "sk-ws-01-xxxxxxxxxx",
  "password": "testpass1",
  "name": "Test User 1"
}
```

### 示例 3：登录失败处理

如果自动登录失败（密码错误、网络问题等）：

**错误响应：**
```json
{
  "detail": "账号 API Key 获取失败: 密码错误"
}
```

**系统行为：**
- 账号保持 unused 状态
- 不计入密钥使用次数
- 下次请求会尝试分配其他账号

## 优势

### 1. 简化账号管理
- 不需要预先获取所有账号的 API Key
- 只需要邮箱和密码即可上传
- 减少账号准备工作

### 2. 按需获取
- API Key 在实际使用时才获取
- 避免提前获取导致的过期问题
- 节省 API 调用次数

### 3. 灵活性
- 支持混合格式（部分有 API Key，部分没有）
- 兼容旧的账号文件格式
- 平滑升级，无需修改现有数据

### 4. 自动化
- 全自动获取流程
- 无需人工干预
- 失败自动重试（下次请求）

## 注意事项

### 1. 首次使用延迟
- 没有 API Key 的账号首次使用时需要额外 2-5 秒
- 用于执行登录和获取 API Key
- 后续使用无延迟

### 2. 密码正确性
- 确保上传的密码正确
- 密码错误会导致 API Key 获取失败
- 建议在上传前验证账号密码

### 3. 网络依赖
- 自动获取需要访问 Firebase 和 Windsurf API
- 确保服务器网络正常
- 网络问题会导致获取失败

### 4. 数据库迁移
- 升级前需要运行迁移脚本
- 建议先备份数据库
- 迁移过程中服务会短暂中断

## 故障排查

### 问题 1：迁移失败

**症状：**
```
sqlalchemy.exc.IntegrityError: NOT NULL constraint failed
```

**解决方案：**
1. 确保已运行迁移脚本
2. 检查数据库连接
3. 手动执行 SQL 迁移

### 问题 2：API Key 获取失败

**症状：**
```
账号 API Key 获取失败: 密码错误
```

**解决方案：**
1. 验证账号密码是否正确
2. 在 Windsurf 官网测试登录
3. 检查网络连接
4. 查看服务器日志

### 问题 3：账号一直处于 unused 状态

**症状：**
- 账号被分配但状态未更新

**解决方案：**
1. 检查是否有错误日志
2. 确认 API Key 获取成功
3. 检查数据库事务是否提交

## 配置选项

### 环境变量

```env
# Firebase API Key（可选，系统会自动获取）
FIREBASE_API_KEY=AIzaSyXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
```

### 超时设置

在 `app/windsurf_login.py` 中可以调整超时时间：

```python
self.client = httpx.AsyncClient(timeout=30.0)  # 默认 30 秒
```

## 测试

### 测试账号上传

```bash
# 创建测试账号文件
cat > test_accounts.txt << EOF
Account 1:
  Email: test@example.com
  Name: Test User
  Password: testpass123
EOF

# 上传账号
curl -X POST "http://localhost:8000/admin/api/accounts/upload" \
  -H "Cookie: admin_session=your_session" \
  -F "files=@test_accounts.txt"
```

### 测试自动获取

```bash
# 获取账号（会自动获取 API Key）
curl -X POST "http://localhost:8000/api/client/account/get" \
  -H "X-API-Key: your_key_code"
```

## 更新日志

### v1.2.0 - 2024-12-09

- ✨ API Key 字段变为可选
- ✨ 自动登录获取 API Key
- ✨ 支持混合格式账号文件
- 🔧 数据库结构更新
- 📝 新增迁移脚本

## 相关文档

- [登录功能说明](LOGIN_FEATURE.md)
- [快速开始指南](QUICK_START_LOGIN.md)
- [更新日志](CHANGELOG.md)
